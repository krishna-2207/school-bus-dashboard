// Real-time Map Component using Leaflet
// Shows bus positions on an actual map with smooth marker movement

import React, { useEffect, useRef, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { LiveLocation, Route } from '../types/firebase';

// Fix Leaflet default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

// Custom bus icon
const busIcon = (isMoving: boolean, status: string) => {
    const color = status === 'overspeed' ? '#EF4444' :
        status === 'stopped' ? '#6B7280' :
            isMoving ? '#22C55E' : '#F59E0B';

    return L.divIcon({
        className: 'bus-marker',
        html: `
      <div style="
        background: ${color};
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 3px solid white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 18px;
      ">🚌</div>
    `,
        iconSize: [36, 36],
        iconAnchor: [18, 18],
        popupAnchor: [0, -20]
    });
};

// Stop icon
const stopIcon = (isSchool: boolean) => {
    return L.divIcon({
        className: 'stop-marker',
        html: `
      <div style="
        background: ${isSchool ? '#3B82F6' : '#F97316'};
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        border: 2px solid white;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        font-size: 12px;
      ">${isSchool ? '🏫' : '📍'}</div>
    `,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
    });
};

// Component to auto-pan to bus
function AutoPan({ location }: { location: LiveLocation | null }) {
    const map = useMap();

    useEffect(() => {
        if (location) {
            map.panTo([location.latitude, location.longitude], { animate: true });
        }
    }, [location?.latitude, location?.longitude]);

    return null;
}

// Props interface
interface LiveMapProps {
    locations: LiveLocation[];
    routes?: Route[];
    selectedBusId?: string;
    onBusClick?: (busId: string) => void;
    height?: string;
    showRoute?: boolean;
    autoPan?: boolean;
}

const LiveMap: React.FC<LiveMapProps> = ({
    locations,
    routes = [],
    selectedBusId,
    onBusClick,
    height = '500px',
    showRoute = true,
    autoPan = false
}) => {
    // Center on Bangalore (default)
    const defaultCenter: [number, number] = [12.9716, 77.5946];
    const [mapCenter, setMapCenter] = useState<[number, number]>(defaultCenter);

    // Get selected bus location
    const selectedLocation = selectedBusId
        ? locations.find(l => l.busId === selectedBusId)
        : locations[0];

    // Get route for selected bus
    const selectedRoute = selectedLocation
        ? routes.find(r => r.id === selectedLocation.routeId)
        : null;

    return (
        <div style={{ height, width: '100%', borderRadius: '12px', overflow: 'hidden' }}>
            <MapContainer
                center={mapCenter}
                zoom={14}
                style={{ height: '100%', width: '100%' }}
                scrollWheelZoom={true}
            >
                {/* Map tiles - you can change the style */}
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />

                {/* Optional: Dark theme tiles */}
                {/* <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        /> */}

                {/* Draw route lines */}
                {showRoute && selectedRoute && (
                    <Polyline
                        positions={selectedRoute.stops.map(stop => [stop.latitude, stop.longitude])}
                        color={selectedRoute.color || '#3B82F6'}
                        weight={4}
                        opacity={0.7}
                        dashArray="10, 10"
                    />
                )}

                {/* Draw stops */}
                {showRoute && selectedRoute?.stops.map((stop, index) => (
                    <React.Fragment key={stop.stopName}>
                        <Marker
                            position={[stop.latitude, stop.longitude]}
                            icon={stopIcon(index === 0)}
                        >
                            <Popup>
                                <div className="text-sm">
                                    <strong>{stop.stopName}</strong>
                                    <br />
                                    ETA: {stop.estimatedArrival} mins
                                </div>
                            </Popup>
                        </Marker>

                        {/* Geofence circle around stops */}
                        <Circle
                            center={[stop.latitude, stop.longitude]}
                            radius={100}
                            color={index === 0 ? '#3B82F6' : '#F97316'}
                            fillOpacity={0.1}
                            weight={1}
                        />
                    </React.Fragment>
                ))}

                {/* Bus markers */}
                {locations.map(location => (
                    <Marker
                        key={location.busId}
                        position={[location.latitude, location.longitude]}
                        icon={busIcon(location.isMoving, location.status)}
                        eventHandlers={{
                            click: () => onBusClick?.(location.busId)
                        }}
                    >
                        <Popup>
                            <div className="p-2 min-w-[200px]">
                                <div className="font-bold text-lg mb-2">
                                    🚌 Bus {location.busId.replace('bus_', '')}
                                </div>
                                <div className="space-y-1 text-sm">
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Speed:</span>
                                        <span className={location.speed > 50 ? 'text-red-500 font-bold' : ''}>
                                            {location.speed.toFixed(1)} km/h
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Status:</span>
                                        <span className={`capitalize ${location.status === 'overspeed' ? 'text-red-500' :
                                                location.status === 'stopped' ? 'text-gray-500' : 'text-green-500'
                                            }`}>
                                            {location.status}
                                        </span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Next Stop:</span>
                                        <span>{location.nextStop}</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span className="text-gray-500">Updated:</span>
                                        <span>
                                            {location.timestamp instanceof Date
                                                ? location.timestamp.toLocaleTimeString()
                                                : 'Just now'}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </Popup>
                    </Marker>
                ))}

                {/* Auto-pan to selected bus */}
                {autoPan && <AutoPan location={selectedLocation || null} />}
            </MapContainer>
        </div>
    );
};

export default LiveMap;
