// Main App Component with Firebase Integration
// This integrates the dashboard with real-time Firebase data

import React, { useState, useEffect } from 'react';
import {
    LayoutDashboard,
    MapPin,
    Gauge,
    Bell,
    UserSquare,
    Users,
    Settings as SettingsIcon,
    Menu,
    X,
    RefreshCw,
    Wifi,
    WifiOff,
    Database
} from 'lucide-react';

// Firebase hooks
import { useBusTracking, useDriver } from './hooks/useBusTracking';

// Components
import LiveMap from './components/LiveMap';
import BusInfoPanel from './components/BusInfoPanel';
import AlertsList from './components/AlertsList';

// Navigation tabs
type NavigationTab =
    | 'Dashboard'
    | 'Live Tracking'
    | 'Speed Monitor'
    | 'Alerts'
    | 'Driver Details'
    | 'Parents'
    | 'Settings';

const navItems: { name: NavigationTab; icon: React.ReactNode }[] = [
    { name: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { name: 'Live Tracking', icon: <MapPin size={20} /> },
    { name: 'Speed Monitor', icon: <Gauge size={20} /> },
    { name: 'Alerts', icon: <Bell size={20} /> },
    { name: 'Driver Details', icon: <UserSquare size={20} /> },
    { name: 'Parents', icon: <Users size={20} /> },
    { name: 'Settings', icon: <SettingsIcon size={20} /> },
];

const App: React.FC = () => {
    const [activeTab, setActiveTab] = useState<NavigationTab>('Dashboard');
    const [selectedBusId, setSelectedBusId] = useState<string>('bus_001');
    const [sidebarOpen, setSidebarOpen] = useState(true);

    // 🔥 Firebase real-time data
    const {
        locations,
        buses,
        routes,
        alerts,
        loading,
        isAuthenticated,
        getBusLocation,
        getBusDetails,
        getRouteDetails,
        seedData
    } = useBusTracking();

    // Get selected bus data
    const selectedLocation = getBusLocation(selectedBusId);
    const selectedBus = getBusDetails(selectedBusId);
    const selectedRoute = selectedLocation ? getRouteDetails(selectedLocation.routeId) : null;

    // Get driver for selected bus
    const { driver: selectedDriver } = useDriver(selectedBus?.driverId || null);

    // Connection status
    const isConnected = locations.length > 0;

    return (
        <div className="flex h-screen overflow-hidden bg-gray-100">
            {/* Sidebar */}
            <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 transform transition-transform duration-300 ease-in-out
        lg:relative lg:translate-x-0
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
                {/* Logo */}
                <div className="h-16 flex items-center justify-between px-4 border-b border-slate-700">
                    <div className="flex items-center gap-2">
                        <span className="text-2xl">🚌</span>
                        <span className="text-white font-bold">BusTrack</span>
                    </div>
                    <button
                        onClick={() => setSidebarOpen(false)}
                        className="lg:hidden text-slate-400 hover:text-white"
                    >
                        <X size={20} />
                    </button>
                </div>

                {/* Connection Status */}
                <div className={`mx-4 mt-4 px-3 py-2 rounded-lg flex items-center gap-2 text-sm ${isConnected ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'
                    }`}>
                    {isConnected ? <Wifi size={16} /> : <WifiOff size={16} />}
                    {isConnected ? 'Live Connected' : 'Connecting...'}
                </div>

                {/* Nav Items */}
                <nav className="mt-4 px-2">
                    {navItems.map((item) => (
                        <button
                            key={item.name}
                            onClick={() => setActiveTab(item.name)}
                            className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-1 transition-colors
                ${activeTab === item.name
                                    ? 'bg-blue-600 text-white'
                                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'}
              `}
                        >
                            {item.icon}
                            <span>{item.name}</span>
                            {item.name === 'Alerts' && alerts.filter(a => a.status === 'active').length > 0 && (
                                <span className="ml-auto bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                                    {alerts.filter(a => a.status === 'active').length}
                                </span>
                            )}
                        </button>
                    ))}
                </nav>

                {/* Bus Selector */}
                <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-700">
                    <label className="text-slate-400 text-xs mb-2 block">Select Bus</label>
                    <select
                        value={selectedBusId}
                        onChange={(e) => setSelectedBusId(e.target.value)}
                        className="w-full bg-slate-800 text-white rounded-lg px-3 py-2 border border-slate-600 focus:outline-none focus:border-blue-500"
                    >
                        {buses.map(bus => (
                            <option key={bus.id} value={bus.id}>
                                {bus.busNumber} - {bus.status}
                            </option>
                        ))}
                        {buses.length === 0 && (
                            <option value="bus_001">Bus 001 (Loading...)</option>
                        )}
                    </select>
                </div>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
                {/* Header */}
                <header className="h-16 bg-white border-b flex items-center justify-between px-4 shadow-sm">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => setSidebarOpen(true)}
                            className="lg:hidden text-gray-500 hover:text-gray-700"
                        >
                            <Menu size={24} />
                        </button>
                        <h1 className="text-xl font-bold text-gray-800">
                            School Bus Safety & Tracking Dashboard
                        </h1>
                    </div>

                    <div className="flex items-center gap-4">
                        {/* Seed Data Button - Only show in Settings */}
                        {activeTab === 'Settings' && (
                            <button
                                onClick={seedData}
                                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                            >
                                <Database size={16} />
                                Seed Initial Data
                            </button>
                        )}

                        {/* Refresh indicator */}
                        {loading && (
                            <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />
                        )}

                        {/* Auth status */}
                        <div className={`px-3 py-1 rounded-full text-sm ${isAuthenticated ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                            }`}>
                            {isAuthenticated ? '✓ Authenticated' : 'Connecting...'}
                        </div>
                    </div>
                </header>

                {/* Main Content Area */}
                <main className="flex-1 overflow-y-auto p-6">
                    {/* Dashboard View */}
                    {activeTab === 'Dashboard' && (
                        <div className="space-y-6">
                            {/* Stats Grid */}
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <StatCard
                                    title="Active Buses"
                                    value={locations.length.toString()}
                                    icon="🚌"
                                    color="blue"
                                />
                                <StatCard
                                    title="Total Routes"
                                    value={routes.length.toString()}
                                    icon="🛤️"
                                    color="green"
                                />
                                <StatCard
                                    title="Active Alerts"
                                    value={alerts.filter(a => a.status === 'active').length.toString()}
                                    icon="⚠️"
                                    color="orange"
                                />
                                <StatCard
                                    title="Avg Speed"
                                    value={locations.length > 0
                                        ? `${(locations.reduce((sum, l) => sum + l.speed, 0) / locations.length).toFixed(1)} km/h`
                                        : '-- km/h'
                                    }
                                    icon="⚡"
                                    color="purple"
                                />
                            </div>

                            {/* Map and Info Panel */}
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                <div className="lg:col-span-2">
                                    <div className="bg-white rounded-xl shadow-lg p-4">
                                        <h2 className="text-lg font-bold mb-4">Live Map</h2>
                                        <LiveMap
                                            locations={locations}
                                            routes={routes}
                                            selectedBusId={selectedBusId}
                                            onBusClick={setSelectedBusId}
                                            height="400px"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <BusInfoPanel
                                        location={selectedLocation}
                                        bus={selectedBus}
                                        driver={selectedDriver}
                                        route={selectedRoute}
                                        loading={loading}
                                    />
                                </div>
                            </div>

                            {/* Recent Alerts */}
                            <div className="bg-white rounded-xl shadow-lg p-6">
                                <h2 className="text-lg font-bold mb-4">Recent Alerts</h2>
                                <AlertsList alerts={alerts.slice(0, 5)} loading={loading} />
                            </div>
                        </div>
                    )}

                    {/* Live Tracking View */}
                    {activeTab === 'Live Tracking' && (
                        <div className="bg-white rounded-xl shadow-lg p-4">
                            <h2 className="text-lg font-bold mb-4">Real-Time Bus Tracking</h2>
                            <LiveMap
                                locations={locations}
                                routes={routes}
                                selectedBusId={selectedBusId}
                                onBusClick={setSelectedBusId}
                                height="calc(100vh - 200px)"
                                autoPan={true}
                            />
                        </div>
                    )}

                    {/* Speed Monitor View */}
                    {activeTab === 'Speed Monitor' && (
                        <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {locations.map(location => (
                                    <SpeedCard key={location.busId} location={location} />
                                ))}
                                {locations.length === 0 && (
                                    <div className="col-span-2 bg-white rounded-xl shadow-lg p-12 text-center text-gray-500">
                                        <Gauge className="w-16 h-16 mx-auto mb-4 opacity-30" />
                                        <p className="text-lg">No buses currently active</p>
                                        <p className="text-sm mt-2">Start the simulator to see speed data</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Alerts View */}
                    {activeTab === 'Alerts' && (
                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <h2 className="text-lg font-bold mb-4">All Alerts</h2>
                            <AlertsList alerts={alerts} loading={loading} />
                        </div>
                    )}

                    {/* Driver Details View */}
                    {activeTab === 'Driver Details' && (
                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <h2 className="text-lg font-bold mb-6">Driver Details</h2>
                            {selectedDriver ? (
                                <div className="flex items-start gap-6">
                                    <img
                                        src={selectedDriver.photo || 'https://via.placeholder.com/150'}
                                        alt={selectedDriver.name}
                                        className="w-32 h-32 rounded-xl object-cover shadow-lg"
                                    />
                                    <div className="space-y-4">
                                        <h3 className="text-2xl font-bold">{selectedDriver.name}</h3>
                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                            <div>
                                                <span className="text-gray-500">Phone</span>
                                                <p className="font-medium">{selectedDriver.phone}</p>
                                            </div>
                                            <div>
                                                <span className="text-gray-500">Email</span>
                                                <p className="font-medium">{selectedDriver.email}</p>
                                            </div>
                                            <div>
                                                <span className="text-gray-500">License</span>
                                                <p className="font-medium">{selectedDriver.licenseNumber}</p>
                                            </div>
                                            <div>
                                                <span className="text-gray-500">Status</span>
                                                <p className={`font-medium capitalize ${selectedDriver.status === 'on-duty' ? 'text-green-600' : 'text-gray-600'
                                                    }`}>{selectedDriver.status}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <p className="text-gray-500">Select a bus to view driver details</p>
                            )}
                        </div>
                    )}

                    {/* Settings View */}
                    {activeTab === 'Settings' && (
                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <h2 className="text-lg font-bold mb-6">Settings & Setup</h2>
                            <div className="space-y-6">
                                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                    <h3 className="font-bold text-blue-800 mb-2">🚀 Quick Start</h3>
                                    <ol className="list-decimal list-inside space-y-2 text-sm text-blue-700">
                                        <li>Click "Seed Initial Data" button above to set up sample data</li>
                                        <li>Open terminal and run: <code className="bg-blue-100 px-2 py-0.5 rounded">npm run simulate</code></li>
                                        <li>Watch the buses move in real-time on the map!</li>
                                    </ol>
                                </div>

                                <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
                                    <h3 className="font-bold text-gray-800 mb-2">📡 Connection Status</h3>
                                    <div className="space-y-2 text-sm">
                                        <p>Authentication: {isAuthenticated ? '✅ Connected' : '❌ Not connected'}</p>
                                        <p>Active Buses: {locations.length}</p>
                                        <p>Routes Loaded: {routes.length}</p>
                                        <p>Active Alerts: {alerts.filter(a => a.status === 'active').length}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Parents View */}
                    {activeTab === 'Parents' && (
                        <div className="bg-white rounded-xl shadow-lg p-6">
                            <h2 className="text-lg font-bold mb-4">Parent Information</h2>
                            <p className="text-gray-500">Parent contact information will be displayed here.</p>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

// Stat Card Component
const StatCard: React.FC<{
    title: string;
    value: string;
    icon: string;
    color: 'blue' | 'green' | 'orange' | 'purple';
}> = ({ title, value, icon, color }) => {
    const colorClasses = {
        blue: 'bg-blue-50 border-blue-200',
        green: 'bg-green-50 border-green-200',
        orange: 'bg-orange-50 border-orange-200',
        purple: 'bg-purple-50 border-purple-200'
    };

    return (
        <div className={`${colorClasses[color]} border rounded-xl p-4`}>
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-gray-500 text-sm">{title}</p>
                    <p className="text-2xl font-bold mt-1">{value}</p>
                </div>
                <span className="text-3xl">{icon}</span>
            </div>
        </div>
    );
};

// Speed Card Component
const SpeedCard: React.FC<{ location: any }> = ({ location }) => {
    const isOverspeed = location.speed > 50;

    return (
        <div className={`bg-white rounded-xl shadow-lg p-6 border-l-4 ${isOverspeed ? 'border-red-500' : 'border-green-500'
            }`}>
            <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">Bus {location.busId.replace('bus_', '')}</h3>
                <span className={`px-3 py-1 rounded-full text-sm ${isOverspeed ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
                    }`}>
                    {location.status}
                </span>
            </div>

            <div className="text-center py-4">
                <span className={`text-5xl font-bold ${isOverspeed ? 'text-red-500' : 'text-gray-900'}`}>
                    {location.speed.toFixed(1)}
                </span>
                <span className="text-gray-500 ml-2">km/h</span>
            </div>

            <div className="w-full bg-gray-200 rounded-full h-3 mt-4">
                <div
                    className={`h-3 rounded-full transition-all duration-500 ${isOverspeed ? 'bg-red-500' : 'bg-green-500'
                        }`}
                    style={{ width: `${Math.min((location.speed / 60) * 100, 100)}%` }}
                />
            </div>
            <p className="text-center text-xs text-gray-400 mt-2">Speed limit: 50 km/h</p>
        </div>
    );
};

export default App;
