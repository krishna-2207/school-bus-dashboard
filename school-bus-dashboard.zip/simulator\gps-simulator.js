/**
 * 🚌 GPS BUS SIMULATOR
 * ====================
 * This simulates realistic bus movement along a route.
 * It writes GPS coordinates to Firestore every 3 seconds.
 * 
 * HOW TO RUN:
 * 1. First, update firebase config below with your credentials
 * 2. Run: npm run simulate
 * 
 * The simulator will:
 * - Move the bus along a predefined route
 * - Vary speed realistically (slower near stops, faster on open road)
 * - Generate alerts for overspeed, geofence entry, etc.
 * - Run until you press Ctrl+C
 */

import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, serverTimestamp, collection } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBbUov44CfuEzUERI9aQwGm8fy06el6z-0",
    authDomain: "bus-tracking-363b8.firebaseapp.com",
    projectId: "bus-tracking-363b8",
    storageBucket: "bus-tracking-363b8.firebasestorage.app",
    messagingSenderId: "811005481984",
    appId: "1:811005481984:web:b96a65582689a2f569f4e5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ========================================
// ROUTE CONFIGURATION (Bangalore, India)
// ========================================
const ROUTE_STOPS = [
    { name: 'Central School', lat: 12.9716, lng: 77.5946, isSchool: true },
    { name: "Emma's Home", lat: 12.9750, lng: 77.5980 },
    { name: "Liam's Home", lat: 12.9800, lng: 77.6020 },
    { name: "Noah's Home", lat: 12.9850, lng: 77.6060 },
    { name: "Olivia's Home", lat: 12.9900, lng: 77.6100 }
];

// Generate detailed waypoints between stops for smooth movement
function generateWaypoints(stops) {
    const waypoints = [];

    for (let i = 0; i < stops.length - 1; i++) {
        const start = stops[i];
        const end = stops[i + 1];

        // Add starting stop
        waypoints.push({
            lat: start.lat,
            lng: start.lng,
            name: start.name,
            isStop: true,
            isSchool: start.isSchool || false
        });

        // Add intermediate points (10 points between each stop)
        const steps = 10;
        for (let j = 1; j < steps; j++) {
            const fraction = j / steps;
            waypoints.push({
                lat: start.lat + (end.lat - start.lat) * fraction,
                lng: start.lng + (end.lng - start.lng) * fraction,
                name: null,
                isStop: false,
                isSchool: false
            });
        }
    }

    // Add final stop
    const lastStop = stops[stops.length - 1];
    waypoints.push({
        lat: lastStop.lat,
        lng: lastStop.lng,
        name: lastStop.name,
        isStop: true,
        isSchool: lastStop.isSchool || false
    });

    return waypoints;
}

// ========================================
// BUS SIMULATOR CLASS
// ========================================
class BusSimulator {
    constructor(busId, routeId, driverId) {
        this.busId = busId;
        this.routeId = routeId;
        this.driverId = driverId;
        this.waypoints = generateWaypoints(ROUTE_STOPS);
        this.currentIndex = 0;
        this.speed = 0;
        this.targetSpeed = 35;
        this.isMoving = true;
        this.stopDuration = 0;
        this.direction = 1; // 1 = forward, -1 = backward
    }

    calculateHeading(from, to) {
        const dLng = (to.lng - from.lng) * Math.PI / 180;
        const lat1 = from.lat * Math.PI / 180;
        const lat2 = to.lat * Math.PI / 180;

        const y = Math.sin(dLng) * Math.cos(lat2);
        const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);

        let heading = Math.atan2(y, x) * 180 / Math.PI;
        return (heading + 360) % 360;
    }

    getNextStopName() {
        for (let i = this.currentIndex + 1; i < this.waypoints.length; i++) {
            if (this.waypoints[i].isStop) {
                return this.waypoints[i].name;
            }
        }
        return ROUTE_STOPS[0].name; // Loop back to school
    }

    getStatus() {
        if (this.speed <= 0.5) return 'stopped';
        if (this.speed > 50) return 'overspeed';
        return 'normal';
    }

    async update() {
        const current = this.waypoints[this.currentIndex];

        // Handle stop duration
        if (current.isStop && this.stopDuration > 0) {
            this.stopDuration--;
            this.speed = Math.max(0, this.speed - 5);
            this.isMoving = false;

            console.log(`🛑 Stopped at ${current.name} (${this.stopDuration}s remaining)`);
        } else {
            this.isMoving = true;

            // Move to next waypoint
            this.currentIndex += this.direction;

            // Reverse direction at ends
            if (this.currentIndex >= this.waypoints.length - 1) {
                this.direction = -1;
                console.log('🔄 Reversing direction (heading back to school)');
            } else if (this.currentIndex <= 0) {
                this.direction = 1;
                console.log('🔄 Reversing direction (starting pickup route)');
            }

            const next = this.waypoints[this.currentIndex];

            // If next is a stop, prepare to stop
            if (next.isStop) {
                this.targetSpeed = 0;
                this.stopDuration = next.isSchool ? 10 : 5; // Longer stop at school
                console.log(`📍 Approaching ${next.name}`);
            } else {
                // Vary speed realistically
                this.targetSpeed = 30 + Math.random() * 15; // 30-45 km/h
            }
        }

        // Smooth speed transitions
        if (this.speed < this.targetSpeed) {
            this.speed = Math.min(this.speed + 2, this.targetSpeed);
        } else if (this.speed > this.targetSpeed) {
            this.speed = Math.max(this.speed - 3, this.targetSpeed);
        }

        // Add some jitter for realism
        this.speed += (Math.random() - 0.5) * 2;
        this.speed = Math.max(0, this.speed);

        // Random overspeed event (5% chance)
        if (Math.random() < 0.05 && this.isMoving) {
            this.speed = 52 + Math.random() * 5;
            console.log('⚠️ Overspeed detected!');
            await this.createAlert('overspeed', `Bus ${this.busId} exceeded speed limit: ${this.speed.toFixed(1)} km/h`);
        }

        const currentPos = this.waypoints[this.currentIndex];
        const nextIndex = Math.min(this.currentIndex + 1, this.waypoints.length - 1);
        const nextPos = this.waypoints[nextIndex];

        // Write to Firestore
        const locationData = {
            busId: this.busId,
            driverId: this.driverId,
            latitude: currentPos.lat,
            longitude: currentPos.lng,
            heading: this.calculateHeading(currentPos, nextPos),
            speed: parseFloat(this.speed.toFixed(1)),
            accuracy: 5 + Math.random() * 10,
            timestamp: serverTimestamp(),
            isMoving: this.isMoving,
            routeId: this.routeId,
            nextStop: this.getNextStopName(),
            status: this.getStatus()
        };

        await setDoc(doc(db, 'liveLocations', this.busId), locationData);

        console.log(
            `🚌 ${this.busId} | ` +
            `📍 ${currentPos.lat.toFixed(4)}, ${currentPos.lng.toFixed(4)} | ` +
            `🏃 ${this.speed.toFixed(1)} km/h | ` +
            `${this.isMoving ? '🟢 Moving' : '🔴 Stopped'}`
        );
    }

    async createAlert(type, message) {
        const alertData = {
            busId: this.busId,
            type,
            message,
            severity: type === 'overspeed' ? 'medium' : 'low',
            status: 'active',
            createdAt: serverTimestamp()
        };

        await setDoc(doc(collection(db, 'alerts')), alertData);
    }
}

// ========================================
// MAIN SIMULATION
// ========================================
console.log('');
console.log('╔════════════════════════════════════════════════════════╗');
console.log('║          🚌 GPS BUS SIMULATOR - Starting               ║');
console.log('╠════════════════════════════════════════════════════════╣');
console.log('║  Simulating 2 buses with real GPS coordinates          ║');
console.log('║  Updates every 3 seconds                               ║');
console.log('║  Press Ctrl+C to stop                                  ║');
console.log('╚════════════════════════════════════════════════════════╝');
console.log('');

// Create simulators for 2 buses
const bus1 = new BusSimulator('bus_001', 'route_001', 'driver_001');
const bus2 = new BusSimulator('bus_002', 'route_002', 'driver_002');

// Offset bus2's starting position
bus2.currentIndex = Math.floor(bus2.waypoints.length / 2);

// Update loop
async function runSimulation() {
    try {
        await bus1.update();
        await bus2.update();
    } catch (error) {
        console.error('❌ Error updating location:', error.message);
    }
}

// Run every 3 seconds
setInterval(runSimulation, 3000);

// Initial update
runSimulation();

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n\n👋 Simulator stopped. Goodbye!');
    process.exit(0);
});
