/**
 * 🌱 DATABASE SEEDER
 * ==================
 * This script creates all the necessary collections and sample data
 * in your Firestore database.
 * 
 * HOW TO RUN:
 * 1. First, update firebase config below with your credentials
 * 2. Run: npm run seed
 */

import { initializeApp } from 'firebase/app';
import {
    getFirestore,
    doc,
    setDoc,
    collection,
    serverTimestamp
} from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBbUov44CfuEzUERI9aQwGm8fy06el6z-0",
    authDomain: "bus-tracking-363b8.firebaseapp.com",
    projectId: "bus-tracking-363b8",
    storageBucket: "bus-tracking-363b8.firebasestorage.app",
    messagingSenderId: "811005481984",
    appId: "1:811005481984:web:b96a65582689a2f569f4e5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// ========================================
// SAMPLE DATA
// ========================================

const BUSES = [
    {
        id: 'bus_001',
        busNumber: 'KA-01-AB-1234',
        capacity: 40,
        currentRouteId: 'route_001',
        driverId: 'driver_001',
        status: 'active',
        type: 'Large',
        year: 2022,
        lastMaintenance: '2025-12-15',
        fuelType: 'Diesel'
    },
    {
        id: 'bus_002',
        busNumber: 'KA-01-CD-5678',
        capacity: 30,
        currentRouteId: 'route_002',
        driverId: 'driver_002',
        status: 'active',
        type: 'Medium',
        year: 2021,
        lastMaintenance: '2026-01-10',
        fuelType: 'CNG'
    },
    {
        id: 'bus_003',
        busNumber: 'KA-01-EF-9012',
        capacity: 45,
        currentRouteId: 'route_003',
        driverId: 'driver_003',
        status: 'maintenance',
        type: 'Large',
        year: 2020,
        lastMaintenance: '2026-01-25',
        fuelType: 'Diesel'
    }
];

const ROUTES = [
    {
        id: 'route_001',
        name: 'Central School Route A',
        description: 'Morning pickup route covering north Bangalore area',
        totalStops: 5,
        estimatedTime: 45,
        distance: 12.5,
        isActive: true,
        stops: [
            { name: 'Central School', latitude: 12.9716, longitude: 77.5946, order: 1, isSchool: true, estimatedArrival: '08:00' },
            { name: "Emma's Home", latitude: 12.9750, longitude: 77.5980, order: 2, isSchool: false, estimatedArrival: '08:10' },
            { name: "Liam's Home", latitude: 12.9800, longitude: 77.6020, order: 3, isSchool: false, estimatedArrival: '08:20' },
            { name: "Noah's Home", latitude: 12.9850, longitude: 77.6060, order: 4, isSchool: false, estimatedArrival: '08:30' },
            { name: "Olivia's Home", latitude: 12.9900, longitude: 77.6100, order: 5, isSchool: false, estimatedArrival: '08:40' }
        ]
    },
    {
        id: 'route_002',
        name: 'Central School Route B',
        description: 'Morning pickup route covering south Bangalore area',
        totalStops: 4,
        estimatedTime: 35,
        distance: 10.2,
        isActive: true,
        stops: [
            { name: 'Central School', latitude: 12.9716, longitude: 77.5946, order: 1, isSchool: true, estimatedArrival: '08:00' },
            { name: "Sophia's Home", latitude: 12.9680, longitude: 77.5900, order: 2, isSchool: false, estimatedArrival: '08:12' },
            { name: "James's Home", latitude: 12.9640, longitude: 77.5860, order: 3, isSchool: false, estimatedArrival: '08:22' },
            { name: "Ava's Home", latitude: 12.9600, longitude: 77.5820, order: 4, isSchool: false, estimatedArrival: '08:32' }
        ]
    },
    {
        id: 'route_003',
        name: 'Central School Route C',
        description: 'Morning pickup route covering east Bangalore area',
        totalStops: 6,
        estimatedTime: 50,
        distance: 15.0,
        isActive: false,
        stops: [
            { name: 'Central School', latitude: 12.9716, longitude: 77.5946, order: 1, isSchool: true, estimatedArrival: '08:00' },
            { name: "Ethan's Home", latitude: 12.9720, longitude: 77.6000, order: 2, isSchool: false, estimatedArrival: '08:10' },
            { name: "Mia's Home", latitude: 12.9730, longitude: 77.6050, order: 3, isSchool: false, estimatedArrival: '08:18' },
            { name: "Lucas's Home", latitude: 12.9740, longitude: 77.6100, order: 4, isSchool: false, estimatedArrival: '08:26' },
            { name: "Isabella's Home", latitude: 12.9750, longitude: 77.6150, order: 5, isSchool: false, estimatedArrival: '08:34' },
            { name: "Mason's Home", latitude: 12.9760, longitude: 77.6200, order: 6, isSchool: false, estimatedArrival: '08:42' }
        ]
    }
];

const DRIVERS = [
    {
        id: 'driver_001',
        name: 'Rajesh Kumar',
        phone: '+91 9876543210',
        email: 'rajesh.kumar@school.edu',
        license: 'KA0120210012345',
        licenseExpiry: '2028-06-15',
        assignedBusId: 'bus_001',
        status: 'active',
        experience: 8,
        rating: 4.8
    },
    {
        id: 'driver_002',
        name: 'Suresh Reddy',
        phone: '+91 9876543211',
        email: 'suresh.reddy@school.edu',
        license: 'KA0120210012346',
        licenseExpiry: '2027-09-20',
        assignedBusId: 'bus_002',
        status: 'active',
        experience: 5,
        rating: 4.6
    },
    {
        id: 'driver_003',
        name: 'Mohammed Ali',
        phone: '+91 9876543212',
        email: 'mohammed.ali@school.edu',
        license: 'KA0120210012347',
        licenseExpiry: '2029-03-10',
        assignedBusId: 'bus_003',
        status: 'inactive',
        experience: 12,
        rating: 4.9
    }
];

const LIVE_LOCATIONS = [
    {
        id: 'bus_001',
        busId: 'bus_001',
        driverId: 'driver_001',
        latitude: 12.9716,
        longitude: 77.5946,
        speed: 0,
        heading: 90,
        accuracy: 5,
        isMoving: false,
        status: 'stopped',
        routeId: 'route_001',
        nextStop: 'Central School'
    },
    {
        id: 'bus_002',
        busId: 'bus_002',
        driverId: 'driver_002',
        latitude: 12.9680,
        longitude: 77.5900,
        speed: 35,
        heading: 180,
        accuracy: 8,
        isMoving: true,
        status: 'normal',
        routeId: 'route_002',
        nextStop: "Sophia's Home"
    }
];

const ALERTS = [
    {
        busId: 'bus_001',
        type: 'geofence',
        message: 'Bus arrived at Central School',
        severity: 'low',
        status: 'active'
    },
    {
        busId: 'bus_002',
        type: 'delay',
        message: 'Bus is running 5 minutes behind schedule',
        severity: 'medium',
        status: 'active'
    },
    {
        busId: 'bus_001',
        type: 'overspeed',
        message: 'Bus exceeded speed limit: 52 km/h in 40 km/h zone',
        severity: 'high',
        status: 'resolved'
    }
];

const ADMINS = [
    {
        id: 'admin_001',
        name: 'School Administrator',
        email: 'admin@school.edu',
        role: 'super_admin',
        permissions: ['all']
    }
];

// ========================================
// SEEDING FUNCTIONS
// ========================================

async function seedCollection(collectionName, items, useIdField = true) {
    console.log(`\n📂 Seeding ${collectionName}...`);

    for (const item of items) {
        try {
            const { id, ...data } = item;
            const docId = useIdField && id ? id : undefined;

            if (docId) {
                await setDoc(doc(db, collectionName, docId), {
                    ...data,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                });
                console.log(`  ✅ Added ${docId}`);
            } else {
                const docRef = doc(collection(db, collectionName));
                await setDoc(docRef, {
                    ...data,
                    createdAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                });
                console.log(`  ✅ Added ${docRef.id}`);
            }
        } catch (error) {
            console.error(`  ❌ Error adding item:`, error.message);
        }
    }
}

async function seedDatabase() {
    console.log('');
    console.log('╔════════════════════════════════════════════════════════╗');
    console.log('║          🌱 DATABASE SEEDER - Starting                 ║');
    console.log('╠════════════════════════════════════════════════════════╣');
    console.log('║  Creating all collections with sample data             ║');
    console.log('╚════════════════════════════════════════════════════════╝');

    try {
        await seedCollection('buses', BUSES);
        await seedCollection('routes', ROUTES);
        await seedCollection('drivers', DRIVERS);
        await seedCollection('liveLocations', LIVE_LOCATIONS);
        await seedCollection('alerts', ALERTS, false);
        await seedCollection('admins', ADMINS);

        console.log('\n');
        console.log('╔════════════════════════════════════════════════════════╗');
        console.log('║          ✅ DATABASE SEEDING COMPLETE!                 ║');
        console.log('╠════════════════════════════════════════════════════════╣');
        console.log('║  Collections created:                                  ║');
        console.log('║  • buses (3 documents)                                 ║');
        console.log('║  • routes (3 documents)                                ║');
        console.log('║  • drivers (3 documents)                               ║');
        console.log('║  • liveLocations (2 documents)                         ║');
        console.log('║  • alerts (3 documents)                                ║');
        console.log('║  • admins (1 document)                                 ║');
        console.log('╚════════════════════════════════════════════════════════╝');
        console.log('\n🎉 You can now run the app with: npm run dev');
        console.log('🚌 Start the simulator with: npm run simulate\n');

    } catch (error) {
        console.error('\n❌ Seeding failed:', error.message);
        console.error('\nMake sure you have:');
        console.error('1. Updated the Firebase config at the top of this file');
        console.error('2. Created a Firestore database in Firebase Console');
        console.error('3. Set security rules to allow writes');
    }

    process.exit(0);
}

// Run the seeder
seedDatabase();
