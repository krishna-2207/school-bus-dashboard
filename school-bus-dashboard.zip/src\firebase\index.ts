// Firebase index - Export all firebase services
export { db, auth } from './config';
export * from './firestore';
export * from './auth';
